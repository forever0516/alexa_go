
// exports.exports_fun1 = function(){
// 	console.log("b of export.js");
// }